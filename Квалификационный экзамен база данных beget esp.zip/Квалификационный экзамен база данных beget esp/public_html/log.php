<?php
require_once 'config.php';
global $pdo;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("HTTP/1.1 200 OK");
    exit;
}
$data = json_decode(file_get_contents("php://input"), true);
if (!$data || !isset($data['user'], $data['status'])) {
    http_response_code(400);
    echo json_encode(["error" => "Неверные данные"]);
    exit;
}
$user = $pdo->quote($data['user']);
$status = $pdo->quote($data['status']);
// Логируем
$stmt = $pdo->prepare("INSERT INTO history (timestamp, user, status) VALUES (NOW(), ?, ?)");
$stmt->execute([$data['user'], $data['status']]);
$stmt->closeCursor();
echo json_encode(["status" => "logged"]);
?>