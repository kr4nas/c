<?php
header('Content-Type: application/json');
require_once 'config.php'; // Подключаем config.php с PDO

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    exit;
}

$password = $_GET['password'];

try {
    $stmt = $pdo->prepare("SELECT name FROM users WHERE password = ?");
    $stmt->execute([$password]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $name = $user['name'];
        $access = "разрешен";
    } else {
        $name = "неизвестный";
        $access = "запрещен";
    }

    $time = date("Y-m-d H:i:s");
    $stmt = $pdo->prepare("INSERT INTO history (timestamp, user, status) VALUES (?, ?, ?)");
    $stmt->execute([$time, $name, $access]);

    echo json_encode([
        'status' => $access,
        'name' => $name
    ]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error']);
}
?>
