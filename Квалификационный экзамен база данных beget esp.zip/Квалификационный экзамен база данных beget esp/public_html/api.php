<?php
require_once 'config.php';

global $pdo;

if ($_GET['action'] == 'get_users') {
    try {
        $stmt = $pdo->query("SELECT * FROM users");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($users);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Ошибка запроса: ' . $e->getMessage()]);
    }
}

if ($_GET['action'] == 'get_history') {
    try {
        $stmt = $pdo->query("SELECT * FROM history ORDER BY timestamp DESC LIMIT 100");
        $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($history);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Ошибка запроса: ' . $e->getMessage()]);
    }
}

if ($_GET['action'] == 'update_users') {
    $data = json_decode(file_get_contents("php://input"), true);
    if (!$data) {
        echo json_encode(["status" => "error"]);
        exit;
    }

    foreach ($data as $user) {
        // Если id = 0 — значит, это новый пользователь
        if ($user['id'] == 0) {
            $stmt = $pdo->prepare("INSERT INTO users (name, login, password, role) VALUES (?, ?, ?, ?)");
            $stmt->execute([$user['name'], $user['login'], $user['password'], $user['role']]);
        } else {
            // Если user['id'] существует, обновляем
            $stmt = $pdo->prepare("UPDATE users SET name = ?, login = ?, password = ?, role = ? WHERE id = ?");
            $stmt->execute([$user['name'], $user['login'], $user['password'], $user['role'], $user['id']]);
        }
    }
    echo json_encode(["status" => "success"]);
}

// === Действие: Очистка истории ===
if ($_GET['action'] == 'clear_history') {
    try {
        $stmt = $pdo->prepare("DELETE FROM history");
        $stmt->execute();
        echo json_encode(["status" => "success"]);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Ошибка очистки: ' . $e->getMessage()]);
    }
}

if ($_GET['action'] == 'delete_user') {
    $id = $_GET['id'];
    if (!is_numeric($id)) {
        echo json_encode(["status" => "error", "message" => "Неверный ID"]);
        exit;
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(["status" => "success"]);
    } catch (PDOException $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}

// api.php
if ($_GET['action'] == 'check_admin') {
    $login = $_GET['login'];
    $password = $_GET['password'];

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ? AND password = ?");
        $stmt->execute([$login, $password]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && $user['role'] == 'admin') {
            echo json_encode(['result' => true]);
        } else {
            echo json_encode(['result' => false]);
        }
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Ошибка проверки: ' . $e->getMessage()]);
    }
}