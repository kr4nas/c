<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Content-Type: application/json");

// Настройки подключения к БД
define('DB_HOST', 'omrefofeg.beget.app');
define('DB_PORT', '3306');
define('DB_NAME', 'AAaa');
define('DB_USER', 'AAaa');
define('DB_PASSWORD', '111AAAaaa!!!');

// Подключение к БД
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME,
        DB_USER,
        DB_PASSWORD
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['error' => 'Ошибка подключения к БД: ' . $e->getMessage()]));
}
?>
