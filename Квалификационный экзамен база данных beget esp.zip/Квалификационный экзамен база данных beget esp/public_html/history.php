<?php
header('Content-Type: application/json');
$conn = new mysqli("omrefofeg.beget.app:3306", "AAaa", "111AAAaaa!!!", "AAaa");
$result = $conn->query("SELECT * FROM history ORDER BY timestamp DESC LIMIT 50");
$history = [];
while ($row = $result->fetch_assoc()) {
    $history[] = $row;
}
echo json_encode($history);
?>