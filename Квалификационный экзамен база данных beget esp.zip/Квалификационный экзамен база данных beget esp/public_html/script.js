document.addEventListener("DOMContentLoaded", function () {
  let users = [];
  let history = [];

  // === Загрузка пользователей и истории ===
  async function loadData() {
    console.log("Запрос данных с сервера...");
    try {
      const [usersRes, historyRes] = await Promise.all([
        fetch('api.php?action=get_users'),
        fetch('api.php?action=get_history')
      ]);
      if (!usersRes.ok || !historyRes.ok) {
        throw new Error("Ошибка загрузки данных");
      }
      users = await usersRes.json();
      history = await historyRes.json();
    } catch (error) {
      console.error("Не удалось загрузить данные с сервера:", error);
      alert("Ошибка подключения к серверу");
    }
  }
  
  // === Очистка истории ===
const clearHistoryBtn = document.getElementById("clearHistoryBtn");
if (clearHistoryBtn) {
  clearHistoryBtn.addEventListener("click", async function () {
    if (!confirm("Вы уверены, что хотите очистить всю историю доступа?")) return;
    try {
      const response = await fetch("api.php?action=clear_history", {
        method: "GET"
      });
      const result = await response.json();
      if (result.status === "success") {
        alert("История успешно очищена");
        document.getElementById("historyList").innerHTML = "";
      } else {
        throw new Error(result.error);
      }
    } catch (err) {
      console.error("Ошибка очистки истории:", err);
      alert("Не удалось очистить историю: " + err.message);
    }
  });
}

  // === Авторизация ===
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", async function (e) {
      e.preventDefault();
      const login = document.getElementById("login").value.trim();
      const password = document.getElementById("password").value.trim();
      await loadData();
      const user = users.find(u => u.login === login);
      let status = "";
      if (!user) {
        status = "неизвестный пользователь";
      } else if (user.password !== password) {
        status = "неверный пароль";
      }
      const now = new Date().toLocaleString();
      let logUser = "неизвестный";
      let logStatus = status;
      if (user && user.password === password) {
        localStorage.setItem("auth", "true");
        window.location.href = "index.html";
        logUser = user.name;
        logStatus = "успешно";
      }
      
      try {
        const response = await fetch("log.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ user: logUser, status: logStatus, code: password })
        });
        if (!response.ok) throw new Error("Ошибка отправки данных");
      } catch (err) {
        console.error("Ошибка отправки лога:", err);
      }
    });
  }

  // === История доступа ===
  const historyList = document.getElementById("historyList");
  

  // === Пользователи (редактирование) ===
  const userTableBody = document.getElementById("userTableBody");
  if (userTableBody) {
    let editing = false;

// // === Переключение режима редактирования ===
window.toggleEdit = function () {
  const rows = document.querySelectorAll('#userTableBody tr');
  const isEditing = rows[0]?.querySelector('input') !== null;

  rows.forEach((row, index) => {
    const cells = row.querySelectorAll('td');
    const userData = users[index];

    if (!isEditing) {
      // === РЕЖИМ РЕДАКТИРОВАНИЯ ===
      const nameInput = `<input type="text" value="${userData.name}" class="form-control form-control-sm">`;
      const loginInput = `<input type="text" value="${userData.login}" class="form-control form-control-sm">`;
      const passwordInput = `<input type="text" value="${userData.password}" class="form-control form-control-sm editable-password" maxlength="3">`;
      const roleSelect = `
        <select class="form-select form-select-sm">
          <option value="admin" ${userData.role === 'admin' ? 'selected' : ''}>Администратор</option>
          <option value="user" ${userData.role === 'user' ? 'selected' : ''}>Пользователь</option>
        </select>
      `;
      const deleteBtn = `<button class="btn btn-danger btn-sm" onclick="deleteUser(${userData.id})">Удалить</button>`;

      cells[0].innerHTML = nameInput;
      cells[1].innerHTML = loginInput;
      cells[2].innerHTML = passwordInput; // Без точки, без кнопки 👁
      cells[3].innerHTML = roleSelect;
      cells[4].innerHTML = deleteBtn;
    } else {
      // === РЕЖИМ ПРОСМОТРА ===
      const inputs = row.querySelectorAll('input, select');
      const name = inputs[0].value.trim();
      const login = inputs[1].value.trim();
      const password = inputs[2].value.trim();
      const role = inputs[3].value;

      cells[0].innerText = name;
      cells[1].innerText = login;
      cells[2].innerText = password ? '••••••' : ''; // Возвращаем точки
      cells[3].innerText = role === 'admin' ? 'Администратор' : 'Пользователь';
      cells[4].innerHTML = `<button class="btn btn-danger btn-sm" onclick="deleteUser(${users[index].id})">Удалить</button>`;
    }
  });

  const btn = document.querySelector('[onclick="toggleEdit"]');
  btn.innerText = isEditing ? 'Изменить данные' : 'Отменить изменения';
};

// === Отображение/скрытие пароля в режиме просмотра ===
function setupPasswordToggles() {
  document.querySelectorAll('.toggle-password-eye').forEach(btn => {
    btn.addEventListener('click', function () {
      const cell = this.parentElement;
      const isHidden = cell.textContent.includes('••••••');
      const pwdIndex = [...cell.parentElement.children].indexOf(cell);
      const userIdx = [...cell.parentElement.parentElement.children].indexOf(cell.parentElement);
      const user = users[userIdx];

      if (isHidden) {
        cell.innerHTML = `${user.password}<button class="btn btn-outline-secondary btn-sm toggle-password-eye ms-2" type="button">👁</button>`;
      } else {
        cell.innerHTML = `••••••<button class="btn btn-outline-secondary btn-sm toggle-password-eye ms-2" type="button">👁</button>`;
      }

      // Переназначаем обработчики событий, так как innerHTML заменяет элемент
      setupPasswordToggles(); // Рекурсивно перепривязываем события
    });
  });
}

// === Обновление данных (сохранение с проверкой уникальности логинов и паролей) ===
window.saveData = async function () {
  const isEditing = document.querySelector('#userTableBody tr input') !== null;

  if (isEditing) {
    const rows = document.querySelectorAll('#userTableBody tr');
    const updatedUsers = [];
    const logins = new Set();
    const passwords = new Set();

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const inputs = row.querySelectorAll('input, select');
      const userData = users[i];

      const name = inputs[0].value.trim();
      const login = inputs[1].value.trim();
      const password = inputs[2].value.trim();
      const role = inputs[3].value;

      // Проверка: все поля обязательны
      if (!name || !login || !password) {
        alert(`Строка ${i + 1}: Заполните все поля (ФИО, логин, пароль).`);
        return;
      }

      // Проверка длины пароля
      if (password.length > 3) {
        alert(`Пароль "${password}" слишком длинный (максимум 3 символа).`);
        return;
      }

      // Проверка дубликатов логина
      if (logins.has(login)) {
        alert(`Логин "${login}" уже используется.`);
        return;
      }
      logins.add(login);

      // Проверка дубликатов пароля
      if (passwords.has(password)) {
        alert(`Пароль "${password}" уже используется другим пользователем.`);
        return;
      }
      passwords.add(password);

      updatedUsers.push({
        id: userData.id,
        name,
        login,
        password,
        role
      });
    }

    try {
      const response = await fetch('api.php?action=update_users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedUsers)
      });

      if (response.ok) {
        alert('Данные успешно обновлены');
      } else {
        throw new Error('Ошибка сохранения данных.');
      }
    } catch (err) {
      console.error('Ошибка:', err);
      alert('Не удалось сохранить изменения.');
      return;
    }
  }

  // В любом случае — обновляем данные с сервера
  await loadData();
  renderUsers();

  // Возвращаем кнопку в исходное состояние
  const btn = document.querySelector('[onclick="toggleEdit"]');
  if (btn) btn.innerText = 'Изменить данные';
};

// === Отрисовка таблицы пользователей ===
window.renderUsers = async function() {
  await loadData();
  userTableBody.innerHTML = '';
  users.forEach((user, index) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${user.name}</td>
      <td>${user.login}</td>
      <td>••••••</td>
      <td>${user.role === "admin" ? "Администратор" : "Пользователь"}</td>
      <td><button class="btn btn-danger btn-sm" onclick="deleteUser(${user.id})">Удалить</button></td>
    `;
    userTableBody.appendChild(tr);
  });
};

    window.renderUsers();
  }

// === Добавление пользователя (с проверкой уникальности логина и пароля) ===
const addUserForm = document.getElementById("addUserForm");
if (addUserForm) {
  addUserForm.addEventListener("submit", async function (e) {
    e.preventDefault();
    const name = this.querySelectorAll("input")[0].value.trim();
    const login = this.querySelectorAll("input")[1].value.trim();
    const password = this.querySelectorAll("input")[2].value.trim();
    const role = this.querySelector("select").value;

    // Проверка обязательных полей
    if (!name || !login || !password) {
      alert("Заполните все поля");
      return;
    }

    // Проверка длины пароля
    if (password.length > 3) {
      alert("Пароль не может быть длиннее 3 символов.");
      return;
    }

    // Загружаем актуальные данные с сервера
    await loadData();

    // Проверка: логин уже существует
    if (users.some(u => u.login === login)) {
      alert(`Пользователь с логином "${login}" уже существует.`);
      return;
    }

    // Проверка: пароль уже используется
    if (users.some(u => u.password === password)) {
      alert(`Пароль "${password}" уже используется другим пользователем. Пароли должны быть уникальными.`);
      return;
    }

    // Создаём нового пользователя
    const newUser = { id: 0, name, login, password, role };

    try {
      const response = await fetch("api.php?action=update_users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify([...users, newUser])
      });

      if (response.ok) {
        alert("Пользователь добавлен!");
        setTimeout(() => window.location.href = "users.html", 1000);
      } else {
        throw new Error("Ошибка сохранения");
      }
    } catch (err) {
      console.error("Ошибка обновления пользователей:", err);
      alert("Ошибка при сохранении данных");
    }
  });
}

  // === Удаление пользователя ===
  window.deleteUser = async function (id) {
    if (!confirm("Вы уверены, что хотите удалить этого пользователя?")) return;

    try {
        const response = await fetch(`api.php?action=delete_user&id=${id}`, {
            method: "GET"
        });
        const result = await response.json();
        if (result.status === "success") {
            alert("Пользователь успешно удален");
            await loadData();
            renderUsers();
        } else {
            alert("Ошибка: " + result.message);
        }
    } catch (err) {
        console.error(err);
        alert("Ошибка удаления пользователя");
    }
};
  
});

// === ЭКСПОРТ В WORD ЧЕРЕЗ html-docx-js ===
document.getElementById("downloadWordBtn")?.addEventListener("click", function () {
  try {
    if (typeof htmlDocx === 'undefined' || typeof saveAs === 'undefined') {
      alert("Ошибка: html-docx-js или FileSaver не загружены");
      return;
    }

    // Формируем HTML-содержимое
    const content = `
      <h1 style="text-align: center;">История доступа</h1>
      <p style="text-align: center; font-style: italic; color: #555;">
        Сформировано: ${new Date().toLocaleString("ru-RU")}
      </p>
      <table border="1" cellpadding="5" cellspacing="0" style="width: 100%; border-collapse: collapse;">
        <thead>
          <tr style="background-color: #4472C4; color: white;">
            <th style="padding: 10px; text-align: left;">Время</th>
            <th style="padding: 10px; text-align: left;">Пользователь</th>
            <th style="padding: 10px; text-align: left;">Статус</th>
          </tr>
        </thead>
        <tbody>
          ${Array.from(document.querySelectorAll("#historyList tr"))
            .map(tr => {
              const cells = tr.querySelectorAll("td");
              const time = cells[0]?.innerText || "";
              const user = cells[1]?.innerText || "";
              // Берём готовый текст из ячейки, но убираем эмодзи
              let status = cells[2]?.innerText || "";
              status = status
                .replace("✅", "")
                .replace("❌", "")
                .trim();
              return `<tr>
                <td style="padding: 8px; border: 1px solid #ddd;">${time}</td>
                <td style="padding: 8px; border: 1px solid #ddd;">${user}</td>
                <td style="padding: 8px; border: 1px solid #ddd;">${status}</td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>
    `;

    const converted = htmlDocx.asBlob(content, {
      orientation: 'portrait',
      margins: { top: 720, bottom: 720, left: 720, right: 720 }
    });

    saveAs(converted, `history_${new Date().toISOString().split("T")[0]}.docx`);

  } catch (err) {
    console.error("Ошибка при экспорте в Word:", err);
    alert("Не удалось создать файл.");
  }
});

// === Автообновление истории ===
function fetchHistory() {
  fetch('/api.php?action=get_history')
    .then(res => res.json())
    .then(data => {
      const historyList = document.getElementById('historyList');
      if (!historyList) return;
      historyList.innerHTML = '';
      data.forEach(entry => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${entry.timestamp}</td>
          <td>${entry.user}</td>
          <td>
            ${entry.status === "разрешен" ? "✅ Доступ разрешён" :
              entry.status === "неизвестный" ? "❌ Неизвестный пользователь" : "❌ Неверный пароль"}
          </td>
        `;
        historyList.appendChild(tr);
      });
    })
    .catch(err => console.error(err));
}

setInterval(fetchHistory, 5000);
fetchHistory(); // Загружаем один раз при старте